package Hands5;

public class Data {
    double x[] = { 23, 26, 30, 34, 43, 48, 52, 57, 58 };
    double y[] = { 651, 762, 856, 1063, 1190, 1298, 1421, 1440, 1518 };
    // double x[] = { 1,2,3,4,5,6,7,8,9,10 };
    // double y[] = { 2,4,6,8,10,12,14,16,18,20 };

    public double[] getX() {
        return x;
    }

    public double[] getY() {
        return y;
    }
}
